import pandas as pd
import statsmodels.api as sm

# Load the World Indicators data from "World Indicators.csv"


# Your code starts after this line



# Your code ends before this line

# Create a linear model between year and population in the US

# Your code starts after this line

 
# Your code ends before this line

# Predict the expected population in the US in 2015

# Your code starts after this line


# Your code ends before this line

# For the data from Europe
# Create a linear model between Life Expectancy Female and the significant predictors among
#  Birth Rate
#  GDP
#  Health Exp % GDP
#  Infant Mortality Rate
#  Life Expectancy Male

# Summarize your model (only the final one)

# Hint: if you hit an issue with NaNs in the values consider using this: missing='drop'

# Your code starts after this line


# Your code ends before this line

# Predict the Expected Life Expectancy Female of a country with this characteristics
#  Birth Rate = 3%
#  GDP = 1 billion
#  Health Exp % GDP = 4%
#  Infant Mortality Rate = 5%
#  Life Expectancy Male = 80
# Round the prediction to two decimal points

# Your code starts after this line


# Your code ends before this line

